
Hi {{company}} Hiring Team,

I'm excited to apply for the {{job_title}} role. With over X years delivering AI-driven products that reach millions, I'm confident I can contribute immediately.

Key wins relevant to you:
• Example achievement 1
• Example achievement 2

Looking forward to discussing how my background fits.

Best regards,
Your Name
